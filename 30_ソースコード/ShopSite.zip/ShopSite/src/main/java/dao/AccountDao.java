package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import entity.AccountEntity;

public class AccountDao extends AbstractDao {
	
	public AccountEntity select(String name, String password) throws NamingException, SQLException {
		Connection connection = super.getConnection();
		//■select文を作る
		String sql = "SELECT * FROM account WHERE name = '" + name +"' AND password = '" + password +"';";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();

			AccountEntity entity = null;
			if (resultSet.next()) {
				entity = new AccountEntity();
				entity.setUser_id(resultSet.getInt("id"));
				entity.setUser_password(resultSet.getString("password"));
				entity.setUser_name(resultSet.getString("name"));
			}

			resultSet.close();
			preparedStatement.close();
			super.closeConnection();
			return entity;
	}
	
	public int countNumber() throws SQLException{
		Connection connection = super.getConnection();
		//■select文を作る
		String sql = "SELECT id FROM account WHERE id = (SELECT MAX(id) FROM account);";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		
		ResultSet resultSet = preparedStatement.executeQuery();
		
		int accountNumber = 0;
		if(resultSet.next()) {
		int id = resultSet.getInt("id");
		accountNumber = ++id;
		}
		
		resultSet.close();
		preparedStatement.close();
		super.closeConnection();
		
		return accountNumber;
	}

	public AccountEntity insert(int accountId, String name, String password) throws SQLException {
		Connection connection = super.getConnection();
		String sql = "INSERT INTO account VALUES ('" + accountId + "', '" + name + "', '" + password + "');";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			int rows = preparedStatement.executeUpdate();
			
			AccountEntity entity = null;
			if(rows == 1) {
			entity = new AccountEntity();
			entity.setUser_id(accountId);
			entity.setUser_password(password);
			entity.setUser_name(name);
			}
			
			preparedStatement.close();
			super.closeConnection();
			
			return entity;
	}

}
