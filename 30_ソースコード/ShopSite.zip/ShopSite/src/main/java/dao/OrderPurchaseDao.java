package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.OrderPurchaseEntity;
public class OrderPurchaseDao extends AbstractDao {

	// マイページの購入履歴取得に使うメソッド
	public List<OrderPurchaseEntity> select(int user_id) {
		Connection connection = super.getConnection();
		List<OrderPurchaseEntity> OrderHistryEntityList = new ArrayList<>();
		OrderPurchaseEntity entity = null;
		try {
			String sql = "SELECT * FROM orderpurchase WHERE account_id = ?;";
			PreparedStatement preparedStatement = connection
					.prepareStatement(sql);

			preparedStatement.setInt(1, user_id);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				entity = new OrderPurchaseEntity();
				entity.setUser_id(resultSet.getInt("account_id"));
				entity.setItem_id(resultSet.getInt("item_id"));
				entity.setOrder_quantity(resultSet.getInt("order_quantity"));
				entity.setOrder_date(resultSet.getDate("order_date"));
				OrderHistryEntityList.add(entity);
			}

			resultSet.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (Exception e) {
			e.getStackTrace();
		}

		return OrderHistryEntityList;
	}

	// ■購入に使うメソッド
	public void write(List<OrderPurchaseEntity> orderInformation) {
		Connection connection = super.getConnection();
		PreparedStatement preparedStatement = null;
		try {
			for (int i = 0; i < orderInformation.size(); i++) {
				String sql = "insert into orderpurchase ( id, account_id, item_id, order_quantity, order_date)"
						+ "values(?, ?, ?, ?, ?);";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setInt(1,
						orderInformation.get(i).getPurchase_id());
				preparedStatement.setInt(2,
						orderInformation.get(i).getUser_id());
				preparedStatement.setInt(3,
						orderInformation.get(i).getItem_id());
				preparedStatement.setInt(4,
						orderInformation.get(i).getOrder_quantity());
				preparedStatement.setDate(5,
						orderInformation.get(i).getOrder_date());

				int resultSet = preparedStatement.executeUpdate();
			}

			preparedStatement.close();
			super.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// ■購入に使うメソッド
	public int countNumber() throws SQLException {
		Connection connection = super.getConnection();
		// ■select文を作る
		String sql = "SELECT id FROM orderpurchase WHERE id = (SELECT MAX(id) FROM orderpurchase);";
		PreparedStatement preparedStatement = connection.prepareStatement(sql);

		ResultSet resultSet = preparedStatement.executeQuery();

		int orderPurchaseNumber = 0;
		if (resultSet.next()) {
			int id = resultSet.getInt("id");
			orderPurchaseNumber = ++id;
		}

		resultSet.close();
		preparedStatement.close();
		super.closeConnection();

		return orderPurchaseNumber;
	}
}
