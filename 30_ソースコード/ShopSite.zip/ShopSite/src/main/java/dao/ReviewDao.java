package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.ReviewEntity;

public class ReviewDao extends AbstractDao {

	public void insert(ReviewEntity reviewEntity) {

		Connection connection = super.getConnection();

		try {
			String sql = "insert into review ( id, item_id, account_id, review)"
					+ "values(?, ?, ?, ?);";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, reviewEntity.getId());
			preparedStatement.setInt(2, reviewEntity.getItem_id());
			preparedStatement.setInt(3, reviewEntity.getAccount_id());
			preparedStatement.setString(4, reviewEntity.getReview());

			int resultSet = preparedStatement.executeUpdate();
			preparedStatement.close();
			super.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int countNumber() {
		Connection connection = super.getConnection();
		int number = 0;
		try {
			String sql = "SELECT MAX(id) +1 as create_number FROM review;";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				number = resultSet.getInt("create_number");
			}
			resultSet.close();
			preparedStatement.close();
			super.closeConnection();

			return number;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return number;
	}

	public List<ReviewEntity> select(int clickId) {

		List<ReviewEntity> ReviewEntityList = new ArrayList<ReviewEntity>();
		ReviewEntity entity = null;

		try {
			String sql = "SELECT * FROM review WHERE item_id = ?;";

			Connection connection = super.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, clickId);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				entity = new ReviewEntity();
				entity.setId(rs.getInt("id"));
				entity.setItem_id(rs.getInt("item_id"));
				entity.setAccount_id(rs.getInt("account_id"));
				entity.setReview(rs.getString("review"));
				ReviewEntityList.add(entity);
			}

			rs.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (

		SQLException e) {
			e.printStackTrace();
		}

		// SELECTを実行し、結果表を取得

		// 結果表に格納されたレコードの内容を
		// rankingインスタンスに設定し、ArrayListインスタンスに追加
		return ReviewEntityList;
	}
}