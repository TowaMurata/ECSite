package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.ItemEntity;

public class ItemDao extends AbstractDao {

	public List<ItemEntity> ranking() {

		List<ItemEntity> rankingList = new ArrayList<ItemEntity>();
		ItemEntity entity = null;

		try {
			String sql = "SELECT * FROM item ORDER BY stock LIMIT 3 OFFSET 0;";

			Connection connection = super.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				entity = new ItemEntity();
				entity.setId(rs.getInt("id"));
				entity.setName(rs.getString("name"));
				entity.setCategory(rs.getString("category"));
				entity.setStock(rs.getInt("stock"));
				entity.setSales_price(rs.getInt("sales_price"));
				entity.setTarget_gender_code(rs.getString("target_gender_code"));
				entity.setDetail(rs.getString("detail"));
				rankingList.add(entity);
			}

			rs.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (

		SQLException e) {
			e.printStackTrace();
		}

		return rankingList;
	}

	public List<ItemEntity> getItemDetail(List<Integer> itemIdList) {

		Connection connection = super.getConnection();
		List<ItemEntity> OrderItemEntityList = new ArrayList<>();
		ItemEntity entity = null;

		try {
			String sql = "SELECT * FROM item WHERE id = ? ";

			for (int i = 1; i < itemIdList.size(); i++) {
				sql = sql.concat(" OR id = ?");
			}

			sql = sql.concat(";");
			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			for (int i = 0, j = 1; i < itemIdList.size(); i++, j++) {
				preparedStatement.setInt(j, itemIdList.get(i));
			}

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				entity = new ItemEntity();
				entity.setId(resultSet.getInt("id"));
				entity.setName(resultSet.getString("name"));
				entity.setCategory(resultSet.getString("category"));
				entity.setStock(resultSet.getInt("stock"));
				entity.setSales_price(resultSet.getInt("sales_price"));
				entity.setTarget_gender_code(resultSet.getString("target_gender_code"));
				entity.setDetail(resultSet.getString("detail"));
				OrderItemEntityList.add(entity);
			}

			resultSet.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return OrderItemEntityList;

	}

	public ItemEntity getReviewProdcutInfo(int item_id) {

		Connection connection = super.getConnection();
		ItemEntity entity = null;

		try {
			String sql = "SELECT * FROM item WHERE id = ?;";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, item_id);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				entity = new ItemEntity();
				entity.setId(resultSet.getInt("id"));
				entity.setName(resultSet.getString("name"));
				entity.setCategory(resultSet.getString("category"));
				entity.setStock(resultSet.getInt("stock"));
				entity.setSales_price(resultSet.getInt("sales_price"));
				entity.setTarget_gender_code(resultSet.getString("target_gender_code"));
				entity.setDetail(resultSet.getString("detail"));
			}

			resultSet.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return entity;
	}

	public List<ItemEntity> search(String Selectedcategory, String targetGenderCode) {

		Connection connection = super.getConnection();
		List<ItemEntity> itemByCategory = new ArrayList<ItemEntity>();

		try {
			String sql = "SELECT * FROM item WHERE category = '"
					+ Selectedcategory + "' AND target_gender_code = '" + targetGenderCode + "';";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				String category = resultSet.getString("category");
				int stock = resultSet.getInt("stock");
				int sales_price = resultSet.getInt("sales_price");
				String target_gender_code = resultSet.getString("target_gender_code");
				String detail = resultSet.getString("detail");
				ItemEntity ItemEntity = new ItemEntity(id, name, category, stock, sales_price,
						target_gender_code, detail);
				itemByCategory.add(ItemEntity);
			}

			resultSet.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return itemByCategory;
	}

	public List<ItemEntity> search(String targetGenderCode) {

		Connection connection = super.getConnection();
		List<ItemEntity> itemByCategory = new ArrayList<ItemEntity>();

		try {
			String sql = "SELECT * FROM item WHERE target_gender_code = '" + targetGenderCode + "';";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String name = resultSet.getString("name");
				String category = resultSet.getString("category");
				int stock = resultSet.getInt("stock");
				int sales_price = resultSet.getInt("sales_price");
				String target_gender_code = resultSet.getString("target_gender_code");
				String detail = resultSet.getString("detail");
				ItemEntity ItemEntity = new ItemEntity(id, name, category, stock, sales_price,
						target_gender_code, detail);
				itemByCategory.add(ItemEntity);
			}
			resultSet.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return itemByCategory;
	}

	public ItemEntity select(int clickId) {

		ItemEntity clickItem = new ItemEntity();
		clickItem = null;

		Connection connection = super.getConnection();
		//■select文を作る

		try {
			String sql = "SELECT * FROM item WHERE id = ?;";

			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, clickId);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				clickItem = new ItemEntity();
				clickItem.setId(rs.getInt("id"));
				clickItem.setName(rs.getString("name"));
				clickItem.setCategory(rs.getString("category"));
				clickItem.setStock(rs.getInt("stock"));
				clickItem.setSales_price(rs.getInt("sales_price"));
				clickItem.setTarget_gender_code(rs.getString("target_gender_code"));
				clickItem.setDetail(rs.getString("detail"));
			}

			rs.close();
			preparedStatement.close();
			super.closeConnection();
		} catch (

		SQLException e) {
			e.printStackTrace();
		}

		return clickItem;
	}

	//■アイテムデータベースからストックを減らす
	public void reduce(List<Integer> itemId, List<Integer> orderQuantity) throws SQLException {
		List<Integer> stock = new ArrayList<Integer>();
		Connection connection = super.getConnection();
		//■ストック数を受け取る。
		for (int i = 0; i < itemId.size(); i++) {
			String sql = "SELECT stock FROM item WHERE id = " + itemId.get(i) + ";";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				stock.add(resultSet.getInt("stock"));
				resultSet.close();
				preparedStatement.close();
			}
		}
		super.closeConnection();

		connection = super.getConnection();
		//■ストックを上書き保存
		for (int i = 0; i < itemId.size(); i++) {
			int remaining = stock.get(i) - orderQuantity.get(i);
			String sql = "UPDATE item SET stock = " + remaining + " WHERE id = " + itemId.get(i) + ";";
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		}

		super.closeConnection();
	}

}
