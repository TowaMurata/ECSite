package constant;

public class Constant {

	public static final String SESSION_KEY_LOGIN_USER = "LOGIN_ACCOUNT";
	
	public static final String CART_LIST ="CART_LIST";

}
