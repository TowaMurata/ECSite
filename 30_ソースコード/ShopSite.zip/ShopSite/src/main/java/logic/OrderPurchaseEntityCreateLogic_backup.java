package logic;

import java.util.List;

import entity.OrderPurchaseEntity;

public class OrderPurchaseEntityCreateLogic_backup {

	public static OrderPurchaseEntity OrderEntityCreate(int user_id, String Item_id, String Quantity,
			List<OrderPurchaseEntity> list) {

		int item_id = Integer.parseInt(Item_id);
		int quantity = Integer.parseInt(Quantity);

		OrderPurchaseEntity cartEntity = new OrderPurchaseEntity();

		boolean notInCart = listArrangement(item_id, quantity, list);

		if (notInCart) {
			cartEntity.setUser_id(user_id);
			cartEntity.setItem_id(item_id);
			cartEntity.setOrder_quantity(quantity);
			return cartEntity;
		} else {
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i).getItem_id() == item_id) {
					cartEntity = list.get(i);
				}
			}
			return cartEntity;
		}
	}

	public static boolean listArrangement(int item_id, int quantity, List<OrderPurchaseEntity> list) {
		boolean b = true;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getItem_id() == item_id) {
				int newquantity = list.get(i).getOrder_quantity() + quantity;
				list.get(i).setOrder_quantity(newquantity);
				System.out.println("newquantity =>" + newquantity);
				b = false;
			}

		}

		return b;

	}
}
