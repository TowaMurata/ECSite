package logic;

import java.util.List;

import entity.OrderPurchaseEntity;

public class OrderPurchaseEntityCreateLogic {

	public static boolean OrderEntityCreate(int user_id, String Item_id, String Quantity,
			List<OrderPurchaseEntity> list) {

		boolean overMaxQuantity = false;
		int quantity = Integer.parseInt(Quantity);
		int item_id = Integer.parseInt(Item_id);
		OrderPurchaseEntity cartEntity = getOrderPurchaseEntity(item_id, list);
		if (cartEntity == null) {
			cartEntity = new OrderPurchaseEntity();
			cartEntity.setUser_id(user_id);
			cartEntity.setItem_id(item_id);
			cartEntity.setOrder_quantity(0);
			list.add(cartEntity);
		}
		int currentQuantity = cartEntity.getOrder_quantity();
		int newQuantity = currentQuantity + quantity;
		if (newQuantity > 3) {
			newQuantity = 3;
			overMaxQuantity = true;
		}
		cartEntity.setOrder_quantity(newQuantity);
		return overMaxQuantity;
	}

	private static OrderPurchaseEntity getOrderPurchaseEntity(int item_id, List<OrderPurchaseEntity> list) {
		for (OrderPurchaseEntity cartEntity : list) {
			if (cartEntity.getItem_id() == item_id) {
				return cartEntity;
			}
		}
		return null;
	}

}
