package service;

import dao.ItemDao;
import entity.ItemEntity;

public class ItemDetailService {
	public static ItemEntity itemDetailService(int clickId) {
		ItemEntity clickItem = new ItemEntity();
		ItemDao itemDao = new ItemDao();
		clickItem = itemDao.select(clickId);
		return clickItem;

	}

}
