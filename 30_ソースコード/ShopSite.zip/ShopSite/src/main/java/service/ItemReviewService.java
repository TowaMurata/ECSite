package service;

import java.util.ArrayList;
import java.util.List;

import dao.ReviewDao;
import entity.ReviewEntity;

public class ItemReviewService {
	public static List<ReviewEntity> getReview(int clickId) {
		List<ReviewEntity> ReviewEntityList = new ArrayList<ReviewEntity>();
		ReviewDao reviewDao = new ReviewDao();
		ReviewEntityList = reviewDao.select(clickId);
		return ReviewEntityList;

	}
}
