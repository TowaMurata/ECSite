package service;

import java.util.ArrayList;
import java.util.List;

import dao.ItemDao;
import entity.ItemEntity;

/*
 * プロダクトDAOからプロダクトエンティティを格納したリスト、ランキングリストを返してもらい
 * ホームサーブレットクラスに返すDTO
 */

public class RankingService {

	public static List<ItemEntity> rankingService() {
		List<ItemEntity> rankingList = new ArrayList<ItemEntity>();
		ItemDao itemDao = new ItemDao();
		rankingList = itemDao.ranking();
		return rankingList;

	}
}
