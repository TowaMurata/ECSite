package service;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ItemDao;
import entity.ItemEntity;
import entity.OrderPurchaseEntity;

public class ItemService {
	public static List<ItemEntity> search(String category,String targetGenderCode) {
		
		//■カテゴリーと対象性別をプロダクトDAOのseachメソッドに引数として渡す。
		List<ItemEntity> itemByCategory = new ArrayList<ItemEntity>();
		try {
			ItemDao itemDao = new ItemDao();
			itemByCategory = itemDao.search(category,targetGenderCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return itemByCategory;
	}

	public static List<ItemEntity> search(String targetGenderCode) {
		List<ItemEntity> itemByCategory = new ArrayList<ItemEntity>();
		try {
			ItemDao itemDao = new ItemDao();
			itemByCategory = itemDao.search(targetGenderCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return itemByCategory;
	}
	
	public static List<ItemEntity> chose(List<Integer> itemIdList) {
		List<ItemEntity> itemByCategory = new ArrayList<ItemEntity>();
		try {
			ItemDao itemDao = new ItemDao();
			itemByCategory = itemDao.getItemDetail(itemIdList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return itemByCategory;
	}
	
	public void reduce(List<OrderPurchaseEntity> cartList){
		List<Integer> itemId = new ArrayList<Integer>();
		List<Integer> orderQuantity = new ArrayList<Integer>();
		for(int i = 0; i < cartList.size(); i++) {
			int Id = cartList.get(i).getItem_id();
			itemId.add(Id);
			int quantity = cartList.get(i).getOrder_quantity();
			orderQuantity.add(quantity);
		}
		//■アイテムDaoにidと個数を渡して減らしてもらう。
		ItemDao itemDao = new ItemDao();
		try {
			itemDao.reduce(itemId,orderQuantity);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
