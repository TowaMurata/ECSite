package service;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.naming.NamingException;

import dao.AccountDao;
import entity.AccountEntity;
import util.Utility;

public class AccountService {
	public static AccountEntity search(String userName, String password) {
		
		//■Utilityクラスのdigestメソッドに渡し、ハッシュかされたパスワードをもらう
		String digestPassword = null;
		try {
			digestPassword = Utility.digest(password);
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		//■Daoのselectメソッドで検索処理をしてあればアカウントエンティティ、
		//　なければnullが戻る。
		AccountEntity loginAccount;
		AccountDao accountDao = new AccountDao();
		try {
			loginAccount = accountDao.select(userName, digestPassword);
			return loginAccount;
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	//■アカウントDAOの登録処理を呼び出す
	public static AccountEntity userRegister(String name,String password) {
		
		//■Utilityクラスのdigestメソッドに渡し、ハッシュかされたパスワードをもらう
		String digestPassword = null;
		try {
			digestPassword = Utility.digest(password);
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		//■アカウントDAOの新規ID作成処理を呼び出す
		int id = 0;
		AccountDao accountDao = new AccountDao();
		try {
			id = accountDao.countNumber();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//■ID、名前、パスワードを引数にアカウントDAOのアカウント登録処理を呼び出す
		AccountEntity accountEntity = null;
		try {
			accountEntity = accountDao.insert(id,name,digestPassword);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return accountEntity;
	}

}
