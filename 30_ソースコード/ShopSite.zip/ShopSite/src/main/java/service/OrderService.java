package service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import dao.OrderPurchaseDao;
import entity.OrderPurchaseEntity;

public class OrderService {
	public static List<OrderPurchaseEntity> orderService(
			List<OrderPurchaseEntity> orderInformation) {
		// ■DaoのcountNumberメソッドを呼び出し注文IDを取得
		OrderPurchaseDao orderPerchaseDao = new OrderPurchaseDao();
		int orderId = 0;
		try {
			orderId = orderPerchaseDao.countNumber();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// ■現在の日付を取得してString型に変換
		Calendar calender = Calendar.getInstance();
		Integer year = calender.get(Calendar.YEAR);
		String strYear = year.toString();
		Integer month = calender.get(Calendar.MONTH) + 1;
		String strMonth = month.toString();
		Integer date = calender.get(Calendar.DATE);
		String strDate = date.toString();
		String today = strYear + "-" + strMonth + "-" + strDate;

		//■String型をsqlのDate型に変換
		Date sqlDate= Date.valueOf(today);

		// ■注文情報のリストに上記２つの情報を追加
		for (int i = 0; i < orderInformation.size(); i++) {
			orderInformation.get(i).setPurchase_id(orderId + i);
			orderInformation.get(i).setOrder_date(sqlDate);
		}
		
		// ■オーダーパーチェスDAOのwriteメソッドに注文情報を渡す
		OrderPurchaseDao orderPurchaseDao = new OrderPurchaseDao();
		orderPurchaseDao.write(orderInformation);
		
		return orderInformation;

	}

}
