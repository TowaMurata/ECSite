package entity;

import java.sql.Date;

public class OrderPurchaseEntity {

	private int purchase_id;
	private int user_id;
	private int item_id;
	private int order_quantity;
	private Date order_date;

	public int getPurchase_id() {
		return purchase_id;
	}

	public void setPurchase_id(int purchase_id) {
		this.purchase_id = purchase_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public int getOrder_quantity() {
		return order_quantity;
	}

	public void setOrder_quantity(int order_quantity) {
		this.order_quantity = order_quantity;
	}

	public Date getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}

	//	@Override
	//	public boolean equals(Object object) {
	//		if (object == null) {
	//			return false;
	//		}
	//
	//		if (!(object instanceof OrderPurchaseEntity)) {
	//			return false;
	//		}
	//		OrderPurchaseEntity orderPurchaseEntity = (OrderPurchaseEntity) object;
	//
	//		return this.getItem_id() == orderPurchaseEntity.getItem_id();
	//	}
}
