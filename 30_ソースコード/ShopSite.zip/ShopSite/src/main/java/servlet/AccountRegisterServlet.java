package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.AccountEntity;
import entity.OrderPurchaseEntity;
import service.AccountService;

@WebServlet("/AccountRegisterServlet")
public class AccountRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		doPost(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.removeAttribute("message");
		//■フォーム（送信）データの取得はフレームワークが自動的に実行する
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		
		session = request.getSession();
		
		//■入力された値が規定通りかチェック
		//　違った場合はエラーメッセージを表示して会員登録画面に遷移
		
		if(userName.length() >= 9) {
			session.setAttribute("message","ユーザNAMEは8文字以内で入力してください。");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/accountRegister.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		if(password.length() >= 33) {
			session.setAttribute("message","パスワードは32文字以内で入力してください。");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/accountRegister.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		if(userName.length()== 0 || password.length() == 0) {
			session.setAttribute("message","ユーザNAMEまたはパスワードが間違っています。");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/accountRegister.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		//■アカウントサービスの検索メソッドに渡してすでにあるアカウントかどうかチェックする。
			
			AccountEntity loginAccount = AccountService.search(userName,password);
			
			if (loginAccount != null) {
				//■すでにあるアカウントなので会員登録失敗、登録画面に遷移
				request.setAttribute("message", "すでに存在するアカウントです。");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/accountRegister.jsp");
				dispatcher.forward(request, response);
				return;
			} else {
				//■ないアカウントなので会員登録成功
				
				//アカウントサービスのアカウント登録処理を呼び出す
				loginAccount = AccountService.userRegister(userName,password);
				
				//セッションスコープにアカウント情報を登録
				session.setAttribute("LOGIN_ACCOUNT", loginAccount);
				
				//■カートのセッションスコープを作る
				List<OrderPurchaseEntity> cartList = new ArrayList<OrderPurchaseEntity>();
				session.setAttribute("CART_LIST", cartList);
				
				//■ログインされた状態でホーム画面に遷移する
				RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/registrationComplete.jsp");
				dispatcher.forward(request, response);
			}
			
	}

}
