package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.OrderPurchaseEntity;
import service.ItemService;
import service.OrderService;

@WebServlet("/PurchaseServlet")
public class PurchaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// ■注文情報をセッションスコープから取り出す
		HttpSession session = request.getSession();
		List<OrderPurchaseEntity> cartList = (List<OrderPurchaseEntity>) session
				.getAttribute("CART_LIST");

		//■オーダーサービス、オーダーDAOにカートリストを渡し、データベースに書き込む
		OrderService.orderService(cartList);
		
		//■アイテムサービスにカートリストを渡し、アイテムデータベースのストックを減らす。
		ItemService itemservice = new ItemService();
		itemservice.reduce(cartList);
		
		// ■セッションスコープを空にする
		cartList = new ArrayList<OrderPurchaseEntity>();
		session.setAttribute("CART_LIST", cartList);
		

		// ■購入完了画面に遷移
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("/WEB-INF/purchase.jsp");
		dispatcher.forward(request, response);
	}

}
