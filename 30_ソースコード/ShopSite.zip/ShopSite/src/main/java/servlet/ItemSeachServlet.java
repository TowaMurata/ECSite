package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.ItemEntity;
import service.ItemService;

@WebServlet("/ItemSeachServlet")
public class ItemSeachServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		String targetGenderCode = request.getParameter("targetGenderCode");
		String category = request.getParameter("category");
		
		List<ItemEntity> itemByCategory = new ArrayList<ItemEntity>();
		if (category.equals("ALL")) {
			itemByCategory = ItemService.search(targetGenderCode);
			itemByCategory.get(0).setCategory("ALL");
		} else {
			itemByCategory = ItemService.search(category, targetGenderCode);
		}
		request.setAttribute("itemByCategory", itemByCategory);

		//■商品詳細画面に遷移する。
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/category.jsp");
		dispatcher.forward(request, response);
	}

}
