package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.ItemEntity;
import entity.ReviewEntity;
import service.ItemDetailService;
import service.ItemReviewService;

@WebServlet("/ItemDetailServlet")
public class ItemDetailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String click = request.getParameter("id");
		int clickId = 0;
		if (!(click.equals(null))) {
			clickId = Integer.parseInt(click);
		} else {
			clickId = Integer.parseInt((String) request.getAttribute("id"));
		}

		ItemEntity clickItem = new ItemEntity();
		clickItem = ItemDetailService.itemDetailService(clickId);

		List<ReviewEntity> ReviewEntityList = new ArrayList<ReviewEntity>();
		ReviewEntityList = ItemReviewService.getReview(clickId);

		request.setAttribute("clickItem", clickItem);
		request.setAttribute("ReviewEntityList", ReviewEntityList);

		//■商品詳細画面へ遷移する
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/itemDetail.jsp");
		dispatcher.forward(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

}
