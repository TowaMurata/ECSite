package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.ItemEntity;
import entity.OrderPurchaseEntity;
import service.ItemService;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// ■アイテムサービスからアイテムDAOでアイテム情報を取り出し、リクエストスコープに入れる
		HttpSession session = request.getSession();
		List<OrderPurchaseEntity> cartList = (List<OrderPurchaseEntity>) session
		.getAttribute("CART_LIST");
		
		//■カートに商品が入っていなかったらそのまま画面遷移する
		if(cartList.isEmpty()) {
			List<ItemEntity> orderItemList = new ArrayList<>();
			request.setAttribute("ORDER_ITEM_LIST", orderItemList);
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("/WEB-INF/cart.jsp");
			dispatcher.forward(request, response);
			return;
		}
		
		//■削除ボタンをおされていたらセッションスコープから削除する。
		String deleteId = request.getParameter("delete");
		if(deleteId != null && cartList != null) {
			for(int i = 0; i < cartList.size();i++) {
				if(deleteId.equals(String.valueOf(cartList.get(i).getItem_id()))) {
					cartList.remove(cartList.indexOf(cartList.get(i)));
				}
			}
			session.setAttribute("CART_LIST", cartList);
		}

		//■商品IDをもとに商品情報を取得し、リクエストスコープに入れる。
			List<Integer> list = new ArrayList<>();
			for (int i = 0; i < cartList.size(); i++) {
				int id = cartList.get(i).getItem_id();
				list.add(id);
			}
			List<ItemEntity> orderItemList = ItemService.chose(list);
			request.setAttribute("ORDER_ITEM_LIST", orderItemList);
			

		RequestDispatcher dispatcher = request
				.getRequestDispatcher("/WEB-INF/cart.jsp");
		dispatcher.forward(request, response);
	}

}
