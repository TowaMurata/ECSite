package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.ItemEntity;
import entity.OrderPurchaseEntity;
import service.ItemService;

@WebServlet("/PurchaseConfirmationServlet")
public class PurchaseConfirmationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		//■アイテムサービスからアイテムDAOでアイテム情報を取り出し、リクエストスコープに入れる
		HttpSession session = request.getSession();
		List<OrderPurchaseEntity> cartList = (List<OrderPurchaseEntity>) session
				.getAttribute("CART_LIST");

		//■カート画面で入力した個数を受け取り、CART_LISTのセッションスコープを上書きする。
		if (!(cartList == null)) {
			for (int i = 0; i < cartList.size(); i++) {
				String number = String.valueOf(i);
				String quantity = request.getParameter(number);
				if (!(quantity.equals("1") || quantity.equals("2") || quantity.equals("3"))) {
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("/HomeServlet");
					dispatcher.forward(request, response);
				}
				int purchaseQuantity = Integer.parseInt(quantity);
				cartList.get(i).setOrder_quantity(purchaseQuantity);
				session.setAttribute("CART_LIST", cartList);
			}

			List<Integer> list = new ArrayList<>();
			for (int i = 0; i < cartList.size(); i++) {
				int id = cartList.get(i).getItem_id();
				list.add(id);
			}
			List<ItemEntity> orderItemList = ItemService.chose(list);
			request.setAttribute("ORDER_ITEM_LIST", orderItemList);

		} else {
			List<ItemEntity> orderItemList = new ArrayList<>();
			request.setAttribute("ORDER_ITEM_LIST", orderItemList);
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("/WEB-INF/cart.jsp");
			dispatcher.forward(request, response);
		}

		//■確認画面に遷移
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("/WEB-INF/confirmation.jsp");
		dispatcher.forward(request, response);
	}

}
