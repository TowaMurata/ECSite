package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.AccountEntity;
import entity.OrderPurchaseEntity;
import logic.OrderPurchaseEntityCreateLogic;

@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String clickId = request.getParameter("id");

		HttpSession session = request.getSession();
		AccountEntity LOGIN_ACCOUNT = (AccountEntity) session.getAttribute("LOGIN_ACCOUNT");
		if (LOGIN_ACCOUNT == null) {
			String message = "カートに追加するならログインしてください。";
			session.setAttribute("message", message);

			RequestDispatcher dispatcher = request.getRequestDispatcher("/LoginInitServlet");
			dispatcher.forward(request, response);
			return;
		}
		session = request.getSession();
		session.removeAttribute("message");
		String quantity = request.getParameter("quantity");
		int account_id = LOGIN_ACCOUNT.getUser_id();

		@SuppressWarnings("unchecked")
		List<OrderPurchaseEntity> CART_LIST = (List<OrderPurchaseEntity>) session.getAttribute("CART_LIST");

		//ロジック内の処理でカートリストを更新する
		boolean overMaxQuantity = OrderPurchaseEntityCreateLogic
				.OrderEntityCreate(account_id, clickId, quantity, CART_LIST);

		if (overMaxQuantity) {
			session.setAttribute("duplicationMessage", clickId);
			request.setAttribute("id", clickId);

			RequestDispatcher dispatcher = request
					.getRequestDispatcher("/ItemDetailServlet");
			dispatcher.forward(request, response);
			return;
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("/CartServlet");
		dispatcher.forward(request, response);
		return;
	}

}
