package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.AccountEntity;
import entity.ItemEntity;
import entity.OrderPurchaseEntity;
import service.MypageService;

@WebServlet("/MypageServlet")
public class MypageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//セッションスコープからユーザーIDを取り出す。
		
		HttpSession session = request.getSession();
		AccountEntity account = (AccountEntity)session.getAttribute("LOGIN_ACCOUNT");

		int account_id = account.getUser_id();
		List<OrderPurchaseEntity> OrderPurchaseEntityList = MypageService.getOrderHistoryEntity(account_id);

		List<ItemEntity> OrderItemEntityList = MypageService.ItemInfo(OrderPurchaseEntityList);
		
//		int numberOfPages = 1;
//		for(int i = 5; i < OrderItemEntityList.size(); ) {
//			  numberOfPages++;
//			  i = i + 5;
//		  }
		request.setAttribute("OrderPurchaseEntityList", OrderPurchaseEntityList);
		request.setAttribute("OrderItemEntityList", OrderItemEntityList);
//		request.setAttribute("numberOfPages", numberOfPages);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/mypage.jsp");
		dispatcher.forward(request, response);
		}
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

}
