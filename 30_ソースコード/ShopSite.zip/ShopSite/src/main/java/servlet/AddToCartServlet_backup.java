package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import entity.AccountEntity;
import entity.OrderPurchaseEntity;
import logic.OrderPurchaseEntityCreateLogic_backup;

//@WebServlet("/AddToCartServlet")
public class AddToCartServlet_backup extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String clickId = request.getParameter("id");

		HttpSession session = request.getSession();
		AccountEntity LOGIN_ACCOUNT = (AccountEntity) session.getAttribute("LOGIN_ACCOUNT");
		if (LOGIN_ACCOUNT == null) {
			String message = "カートに追加するならログインしてください。";
			session.setAttribute("message", message);

			RequestDispatcher dispatcher = request.getRequestDispatcher("/LoginInitServlet");
			dispatcher.forward(request, response);
		}
		session = request.getSession();
		session.removeAttribute("message");
		String quantity = request.getParameter("quantity");
		int account_id = LOGIN_ACCOUNT.getUser_id();

		List<OrderPurchaseEntity> CART_LIST = (List<OrderPurchaseEntity>) session.getAttribute("CART_LIST");

		OrderPurchaseEntity cartEntity = OrderPurchaseEntityCreateLogic_backup
				.OrderEntityCreate(account_id, clickId, quantity, CART_LIST);
		System.out.println("cartEntity.getOrder_quantity() => " + cartEntity.getOrder_quantity());

		if (cartEntity.getOrder_quantity() > 3) {
			cartEntity.setOrder_quantity(3);
			System.out.println(cartEntity.getOrder_quantity());
			session.setAttribute("message", "購入できるのは3点までです。");
			request.setAttribute("id", clickId);
			session.setAttribute("CART_LIST", CART_LIST);

			RequestDispatcher dispatcher = request
					.getRequestDispatcher("/ItemDetailServlet");
			dispatcher.forward(request, response);
			return;
		} else {
			boolean notExists = true;
			for (int i = 0; i < CART_LIST.size(); i++) {
				if (CART_LIST.get(i).getItem_id() == Integer.parseInt(clickId)) {
					notExists = false;
					break;
				}

			}
			if (notExists) {
				CART_LIST.add(cartEntity);
			}
			//if (CART_LIST.isEmpty()) {
			//	CART_LIST.add(cartEntity);
			//}
			session.setAttribute("CART_LIST", CART_LIST);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/CartServlet");
			dispatcher.forward(request, response);
			System.out.println("カート追加");
			return;

		}

	}

}
